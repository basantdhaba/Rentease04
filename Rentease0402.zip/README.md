# RentEase

RentEase is a property rental management system built with Next.js, React, and MySQL.

## Getting Started

### Prerequisites

- Node.js (v14 or later)
- MySQL

### Installation

1. Clone the repository:

